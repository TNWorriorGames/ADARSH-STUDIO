TN Warrior Games

How to use:
1. Extract the ZIP.
2. Open index.html in Chrome/Edge.
3. The website works offline.

To put it online for free, upload index.html to a static hosting service such as GitHub Pages or Cloudflare Pages.

The current version includes:
- Home page
- Mini Games page
- Reaction Test
- Number Guess
- About page
- Local best score for Reaction Test

Note: Email login/online accounts are not included yet. That requires connecting an authentication/database service.
